var namespace,
  __slice = [].slice;

namespace = function(target, name, block) {
  var item, top, _i, _len, _ref, _ref1;
  _ref = arguments.length < 3 ? [(typeof exports !== 'undefined' ? exports : window)].concat(__slice.call(arguments)) : void 0, target = _ref[0], name = _ref[1], block = _ref[2];
  top = target;
  _ref1 = name.split('.');
  for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
    item = _ref1[_i];
    target = target[item] || (target[item] = {});
  }
  return block(target, top);
};

namespace("App", function(exports) {
  exports.interact = function(pagePanel) {
    App.scrollTitleChange();
    if (!$("body").hasClass("with-intro")) {
      App.infiniteScrollEvents();
    } else {
      window.scroll(0, 0);
      if (history) {
        history.scrollRestoration = "manual";
      }
    }
    $('body').click(function(e) {
      if ($(this).hasClass("with-intro")) {
        $("body").addClass("animate");
        return setTimeout(function() {
          $("body").removeClass('with-intro animate');
          $("#intro").remove();
          return App.infiniteScrollEvents();
        }, 700);
      }
    });
    $('[event-target=java-card-close], .java-card-close').click(function(e) {
      return $("#java-card").removeClass("visible");
    });
    if (!pagePanel) {
      if ($(window).width() > 1023) {
        $('[data-image]').on('mouseenter', (function(_this) {
          return function(e) {
            return $("#container #page-content .featured-image").append("<img class='lazy lazyload' data-src='" + e.target.getAttribute("data-image") + "'>");
          };
        })(this));
        $('[data-image]').on('mouseleave', (function(_this) {
          return function(e) {
            return $("#container #page-content .featured-image")[0].innerHTML = "";
          };
        })(this));
      }
      $('[event-target=menu]').click(function(e) {
        return $("body").toggleClass("menu-visible");
      });
      $('#page-panel-close').click(function(e) {
        $("body").removeClass("page-panel");
        return setTimeout(function() {
          return $("#page-panel .inner").empty;
        }, 400);
      });
    }
  };
  exports.scrollTitleChange = function() {
    var $header, events, title;
    events = document.querySelector("#events");
    $header = $("header");
    title = $header[0].querySelector("h2");
    return $(window).scroll(function(e) {
      if (events) {
        if ($(events).offset().top - $(window).scrollTop() - $header.height() - 10 < 0) {
          return title.innerHTML = title.getAttribute("data-scroll");
        } else {
          return title.innerHTML = title.getAttribute("data-title");
        }
      }
    });
  };
  exports.infiniteScrollEvents = function() {
    var events, infScroll, nextURL;
    events = document.querySelector("#events");
    if (events) {
      nextURL = document.querySelector(".next-month").getAttribute("href");
      infScroll = new InfiniteScroll(events, {
        path: (function(_this) {
          return function() {
            return nextURL;
          };
        })(this),
        append: ".month",
        checkLastPage: true,
        prefill: true,
        responseType: 'document',
        outlayer: false,
        scrollThreshold: 600,
        loadOnScroll: true,
        history: void 0,
        historyTitle: true,
        hideNav: "#event-pagination",
        status: '.page-load-status',
        button: void 0,
        onInit: void 0,
        debug: false
      });
      infScroll.on('load', function(response, path) {
        return nextURL = response.querySelector(".next-month").getAttribute("href");
      });
    }
  };
  exports.smoothState = function() {
    var options, promoClick, smoothState, target;
    target = null;
    promoClick = 0;
    options = {
      debug: false,
      scroll: false,
      anchors: '[href]:not([data-target=artist])',
      loadingClass: false,
      prefetch: false,
      cacheLength: 4,
      onAction: function($currentTarget, $container) {
        target = $currentTarget.data("target");
        promoClick++;
      },
      onBefore: function(request, $container) {},
      onStart: {
        duration: 400,
        render: function($container) {
          if (target === "artiste") {
            $("body").addClass('page-panel');
          } else {
            $("body").removeClass('page-panel');
          }
          $("body").addClass('is-loading');
        }
      },
      onReady: {
        duration: 400,
        render: function($container, $newContent) {
          if (target === "artiste") {
            $("#page-panel .inner").html($newContent.find("#page-content"));
            App.interact(true);
          } else {
            $(window).scrollTop(0);
            $container.html($newContent);
            App.interact();
          }
        }
      },
      onAfter: function($container, $newContent) {
        $("body").removeClass('is-loading');
        target = null;
        setTimeout(function() {
          $("body").removeClass('menu-visible');
          if (promoClick === 4) {
            return $("#java-card").addClass("visible");
          }
        }, 400);
      }
    };
    smoothState = $("#wrapper").smoothState(options).data('smoothState');
  };
  (exports.init = function() {
    $(window).scrollTop(0);
    window.viewportUnitsBuggyfill.init();
    $(document).ready(function() {
      if ($(window).width() > 1023) {
        App.smoothState();
      }
      return App.interact();
    });
  })();
});

//# sourceMappingURL=scripts.js.map
